# 💰 Catatan Keuangan

Aplikasi pencatatan keuangan pribadi berbasis Flutter yang dirancang untuk membantu pengguna mengelola pemasukan, pengeluaran, utang, piutang, dan tabungan dalam satu aplikasi.

## 📌 Deskripsi Proyek

**Catatan Keuangan** merupakan aplikasi mobile untuk memudahkan pengguna mencatat dan memantau kondisi keuangan pribadi secara terstruktur.

Aplikasi ini dikembangkan menggunakan Flutter dengan pendekatan Feature-First Architecture dan Clean Architecture. Penyimpanan data dirancang menggunakan SQLite melalui Drift sehingga aplikasi dapat dikembangkan dengan pendekatan local-first tanpa harus bergantung pada backend.

## 🎯 Tujuan

- Mempermudah pencatatan pemasukan dan pengeluaran.
- Membantu pengguna memantau saldo keuangan.
- Mengelola utang dan piutang.
- Memantau target serta perkembangan tabungan.
- Menyediakan laporan keuangan yang mudah dipahami.
- Menyediakan fondasi aplikasi yang dapat dikembangkan dengan integrasi REST API.

## ✨ Fitur Aplikasi

Fitur berikut merupakan target pengembangan proyek.

| Fitur | Deskripsi | Status |
|---|---|---|
| Dashboard | Ringkasan kondisi keuangan | Dalam pengembangan |
| Pemasukan | Mencatat transaksi pemasukan | Direncanakan |
| Pengeluaran | Mencatat transaksi pengeluaran | Direncanakan |
| Kategori | Mengelompokkan transaksi | Direncanakan |
| Dompet | Mengelola rekening atau sumber uang | Direncanakan |
| Utang | Mencatat utang dan pembayaran cicilan | Direncanakan |
| Piutang | Mencatat uang yang dipinjamkan | Direncanakan |
| Tabungan | Mengelola target tabungan | Direncanakan |
| Laporan | Menampilkan laporan keuangan | Direncanakan |
| Grafik | Visualisasi pemasukan dan pengeluaran | Direncanakan |
| Multi-bahasa | Bahasa Indonesia dan Inggris | Fondasi disiapkan |
| Tema | Mode terang dan gelap | Fondasi disiapkan |
| Backup | Pencadangan data | Direncanakan |

## 🛠️ Teknologi yang Digunakan

| Teknologi | Kegunaan |
|---|---|
| Flutter | Framework pengembangan aplikasi |
| Dart | Bahasa pemrograman |
| Riverpod | State management |
| GoRouter | Navigasi aplikasi |
| Drift | Database lokal |
| SQLite | Penyimpanan data |
| Dio | HTTP client untuk REST API |
| FL Chart | Visualisasi grafik |
| Intl | Format tanggal dan mata uang |
| Flutter Localizations | Internasionalisasi |
| Local Auth | Autentikasi biometrik |
| Flutter Local Notifications | Notifikasi lokal |
| Path Provider | Pengelolaan lokasi file |

## 🧱 Arsitektur Proyek

Proyek menggunakan pendekatan **Feature-First Architecture** dengan prinsip Clean Architecture.

Pembagian lapisan:

- **Presentation:** Tampilan, halaman, widget, dan state management.
- **Domain:** Entitas, repository interface, dan use case.
- **Data:** Database lokal, remote datasource, DTO, dan implementasi repository.
- **Core:** Komponen umum, konfigurasi, tema, router, dan utility.

## 📂 Struktur Folder

```text
catatan_keuangan/
│
├── assets/
│   ├── images/
│   ├── icons/
│   └── fonts/
│
├── lib/
│   ├── core/
│   │   ├── constants/
│   │   ├── errors/
│   │   ├── router/
│   │   ├── theme/
│   │   ├── utils/
│   │   └── widgets/
│   │
│   ├── data/
│   │   ├── datasources/
│   │   │   ├── local/
│   │   │   │   └── tables/
│   │   │   └── remote/
│   │   ├── dto/
│   │   └── repositories/
│   │
│   ├── domain/
│   │   ├── entities/
│   │   ├── repositories/
│   │   └── usecases/
│   │
│   ├── features/
│   │   ├── dashboard/
│   │   │   └── presentation/
│   │   ├── transactions/
│   │   │   └── presentation/
│   │   ├── debts/
│   │   │   └── presentation/
│   │   ├── savings/
│   │   │   └── presentation/
│   │   ├── reports/
│   │   │   └── presentation/
│   │   ├── settings/
│   │   │   └── presentation/
│   │   └── shared/
│   │
│   ├── l10n/
│   │   ├── app_id.arb
│   │   └── app_en.arb
│   │
│   ├── app.dart
│   └── main.dart
│
├── test/
│   ├── unit/
│   └── widget/
│
├── tool/
│   └── generate_structure.dart
│
├── pubspec.yaml
├── l10n.yaml
└── README.md
```

## ⚙️ Persyaratan Sistem

Sebelum menjalankan proyek, pastikan perangkat sudah memiliki:

- Flutter SDK.
- Dart SDK 3.11.5 atau versi yang memenuhi batas SDK proyek.
- Android Studio atau Visual Studio Code.
- Android SDK atau emulator Android.
- Git (opsional).

Periksa instalasi Flutter:

```bash
flutter doctor
```

Periksa versi Dart:

```bash
dart --version
```

## 🚀 Instalasi dan Menjalankan Proyek

### 1. Clone Repository

```bash
git clone https://github.com/USERNAME/catatan_keuangan.git
```

Masuk ke direktori proyek:

```bash
cd catatan_keuangan
```

### 2. Instal Dependensi

```bash
flutter pub get
```

### 3. Generate Database Drift

Setelah deklarasi tabel dan database Drift selesai dibuat, jalankan:

```bash
dart run build_runner build --delete-conflicting-outputs
```

### 4. Generate Localization

```bash
flutter gen-l10n
```

### 5. Jalankan Aplikasi

```bash
flutter run
```

### 6. Periksa Kode

```bash
flutter analyze
```

## 💵 Format Mata Uang

Aplikasi menggunakan mata uang Rupiah (IDR).

Contoh:

```text
Rp 10.000
Rp 250.000
Rp 1.500.000
Rp 10.000.000
```

Nilai transaksi disimpan sebagai bilangan bulat (integer) untuk menghindari masalah presisi desimal pada perhitungan uang.

## 🗄️ Rancangan Database

Database lokal direnc